#ifndef STEREO_H_
#define STEREO_H_

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <sstream> // for converting the command line parameter to integer
#include <string>
#include <iostream>

#include <iomanip>
#include <string>
#include <fstream>
#include<opencv/highgui.h>

#include "v4l2grab_2.h"


#endif
