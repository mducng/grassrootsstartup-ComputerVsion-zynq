/**
 *    https://github.com/brianwchh/grassrootsstartup-ComputerVsion-zynq
 * */
#include "opencv2/core/core.hpp"
#include "opencv2/opencv.hpp"
#include <iostream>
#include "stdio.h"
#include <unistd.h>

#include <stdlib.h>
#include <iostream>
#include <sstream> // for converting the command line parameter to integer
#include <string>

using namespace std;
using namespace cv;


void help()
{
    printf("use:\ntest rows cols datafile output_image\n");
}
int main(int argc, char *argv[])
{
    // create by using the constructor
    if (argc != 5)
    {
        help();
        return  - 1;
    }
    int rows = atoi(argv[1]);
    int cols = atoi(argv[2]);
    Mat image(rows, cols, CV_8U);
    if (!image.data)
    {
        printf("Error loading");
        return  - 1;
    }
    //cvNamedWindow("show",CV_WINDOW_AUTOSIZE);
    //imshow("show",image);
    //waitKey(0);
    FILE *pfile = fopen(argv[3], "rb");
    if (pfile == NULL)
    {
        printf("Error opening %s", argv[3]);
        return  - 1;
    }

    for (int i = 0; i < image.rows; i++)
    {
        for (int j = 0; j < image.cols; j++)
        {
            unsigned int temp ; 
            fscanf(pfile, "%x\n", &temp);
            image.at<uchar>(i,j) = temp;
        }
    }

    fclose(pfile);

    imwrite(argv[4], image);
    cvNamedWindow("test",CV_WINDOW_AUTOSIZE);
    imshow("test",image);
    waitKey(0);
    return 0;
}
