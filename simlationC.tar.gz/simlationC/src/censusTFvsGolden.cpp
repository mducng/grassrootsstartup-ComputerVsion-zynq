/**
 *    https://github.com/brianwchh/grassrootsstartup-ComputerVsion-zynq
 * */

#include "opencv2/core/core.hpp"
#include "opencv2/opencv.hpp"
#include <iostream>
#include "stdio.h"
#include <unistd.h>

#include <stdlib.h>
#include <iostream>
#include <sstream> // for converting the command line parameter to integer
#include <string>

using namespace std;
using namespace cv;



int main(int argc, char *argv[])
{

    uint64_t*  golden   = new uint64_t[640 * 480] ;
    uint64_t*  dut =new uint64_t[640 * 480] ;

    FILE *pfile_golden = fopen("leftImageCensusTransform.txt", "rb");
    FILE *pfile_dut = fopen("/media/brian/PRO/PROJ/StereoFPGA/stereoIP/moduleSims/census_transform/censusOut.txt", "rb");
    if (pfile_golden == NULL)
    {
        printf("Error opening leftImageCensusTransform.txt");
        return  - 1;
    }

    if (pfile_dut == NULL)
    {
        printf("Error opening /media/brian/PRO/MyPro/StereoFPGA/stereoIP/moduleSims/census_transform/censusOut.txt");
        return  - 1;
    }

    for (int i = 0; i < 480; i++)
    {
        for (int j = 0; j < 640; j++)
        {
            uint64_t  temp ;
            fscanf(pfile_golden, "%lx\n", &temp);
            golden[i*640+j] = temp;
        }
    }
    fclose(pfile_golden);

    for (int i = 0; i < 480; i++)
    {
        for (int j = 0; j < 640; j++)
        {
            uint64_t temp ;
            fscanf(pfile_dut, "%lx\n", &temp);
            dut[i*640+j] = temp;
        }
    }
    fclose(pfile_dut);

    for (int i = 0; i < 480; i++)
    {
        int unmatch = 0;
        int unmatchCnt = 0 ;
        for (int j = 0; j < 640; j++)
        {
           if( dut[i*640+j] != golden[i*640+j] )
           {
                unmatch = 1 ;
                unmatchCnt++;
           }
        }
        if(unmatchCnt)
            printf("row = %d,     unmatchCnt = %d\n ", i,unmatchCnt) ;
    }

    return 0;
}
