/**
 *    https://github.com/brianwchh/grassrootsstartup-ComputerVsion-zynq
 * */

#include <stdlib.h>
#include <iostream>
#include <sstream> // for converting the command line parameter to integer
#include <string>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/contrib/contrib.hpp>

#include <stdio.h>
#include <unistd.h>


#define MAX_SHORT std::numeric_limits<unsigned short>::max()
#define MAX_UCHART std::numeric_limits<unsigned char>::max()

#define  disparity_size_   64
#define PENALTY1 10
#define PENALTY2  60

using namespace std;
using namespace cv;


using namespace cv ;
using namespace std;

static const int HOR = 9;
static const int VERT = 7;



int main(int argc, char* argv[]) {

    Mat left(480,640,CV_8UC1) ;
//    Mat right(480,640,CV_8UC1) ;


     uint8_t*  left_data   = new uint8_t[left.cols * left.rows] ;
//     uint8_t*  right_data = new uint8_t[left.cols * left.rows] ;
     uint32_t tempData ;


    //  ***************    compare modelsim ouput to cpu output  *******************************
        string left_image_file_name = "disparity_from_fpga.txt" ;

       FILE *p_leftdata_fpga = fopen(left_image_file_name.c_str(), "rb");
       if (p_leftdata_fpga == NULL)
       {
           printf("Error opening %s\n", left_image_file_name.c_str());
           return  - 1;
       }

       for (int r  = 0;r < left.rows; r++)
       {
           for (int c = 0; c< left.cols; c++)
           {
                   fscanf(p_leftdata_fpga, "%x\n", &tempData);

//                   left_data[ r *(left.cols ) +  c    ]  = (uint8_t)tempData ;

//                   uint8_t  data3= tempData & 0xFF ;
//                   uint8_t  data2 = ( (tempData >> 8) & (0xFF ) ) ;
//                   uint8_t  data1 = ( (tempData >> 16) & (0xFF ) ) ;
//                   uint8_t  data0 = ( (tempData >> 24) & (0xFF ) ) ;
//                   left_data[ r *(left.cols ) +  c   +  0 ]  = (uint8_t)data0 ;
//                   left_data[ r *(left.cols ) +  c   +  1 ]  =  (uint8_t)data1 ;
//                   left_data[ r *(left.cols ) +  c   +  2 ]  = (uint8_t) data2 ;
//                   left_data[ r *(left.cols ) +  c   +  3 ]  =  (uint8_t)data3 ;

                  uint8_t  data0= tempData & 0xFF ;

                  left_data[ r *(left.cols ) +  c    ]  = (uint8_t)data0 ;

           }
       }
       fclose(p_leftdata_fpga);

       left.data = left_data ;

       for(int i = 0 ; i< 32;i++)
       {
           printf("%02X\n",left_data[i]) ;

       }


       imshow("disparity_from_fpga",left);

       waitKey(0);


}
